<!-- Microchip Design Challenge -->
<!-- 
@file: App.svelte
@brief: This application contains the code that generates a box which can be dragged around
the screen if selected using mouse and then dragged.
Tools: SVELTE.DEV
Author: Akshay Kapse
Mail id: akshaykapsems17@gmail.com
References: https://svelte.dev/examples/dom-event-forwarding & Youtube tutorials (Component importing)
-->

<!-- Importing Box component -->
<script>
	import Draggable from './Draggable.svelte';
</script>

<!-- Defining box component Lable and its default position -->
<Draggable top={20} left={20}>
	<h1>
		Select & Drag
	</h1>
</Draggable>