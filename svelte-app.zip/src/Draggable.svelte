<!-- Microchip Design Challenge -->
<!-- 
@file: App.svelte
@brief: This application contains the code that generates a box which can be dragged around
the screen if selected using mouse and then dragged.
Tools: SVELTE.DEV
Author: Akshay Kapse
Mail id: akshaykapsems17@gmail.com
References: https://svelte.dev/examples/dom-event-forwarding & Youtube tutorials (Component importing)
-->

<script>
	//Declaration of varibales for positioning
	export let left = 30;
	export let top = 30;

	//Variable for tracking the drag condition, initial value: false
	let drag = false; 

	//Function: init 
	//Param: none
	//function to set drag variable to true, it will be true based on mouse inputs: 
	//(clicked down)
	function init() {
		drag = true;
	}

	//Function: stop 
	//Param: none
	//Function to set drag value  = false
	function stop() {
		drag = false;
	}

	//Function: boxdrag 
	//Param: e
	//Function for Box component movement based on mouse movement (X,Y)
	//Condition: drag should be true
	function boxdrag(e) {
			if (drag) {
				left += e.movementX;
				top += e.movementY;
			}
	}	
</script>

<!-- Styling of Box component: 
No text selection, 
absolute positioning so that it can be moved anywhere, 
Border: Solid and Black, Text Color: White, font size std. 1, Box Background: red,
Cursor type: Move, i.e. Whenever cursor is on top of box component, it will 
change type to select and move
-->
<style>
	.Draggable {
		user-select: none;    
		position: absolute;
		border: solid 1px black;
		font-size: 1rem;
		color: white;
		background-color: red;
		cursor: move;
	}
</style>

<!-- Class declaration with slot so that we can use HTML component -->
<section on:mousedown={init} style="left: {left}px; top: {top}px;" class="Draggable">
	<slot></slot>
</section>

<!-- Whenever mouse click is up, stop function will be called, if mouse is moving,
move function will be called-->
<svelte:window on:mouseup={stop} on:mousemove={boxdrag}  />






